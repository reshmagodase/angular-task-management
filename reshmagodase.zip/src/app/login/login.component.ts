import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpserviceService } from '../httpservice.service';
import { error } from 'console';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform:any=FormGroup;

  constructor(private fb:FormBuilder , private serviceobj:HttpserviceService , private router:Router) { }

  ngOnInit(): void {
  this.loginform= this.fb.group({
    username:[],
    password:[],
  })
  }
  onSubmit(){
    console.log(this.loginform.value);
     this.serviceobj.postuserdata(this.loginform.value).subscribe((result:any) =>{
      alert("data added successfully");
      this.router.navigate(['/dashboard']);
     },error =>
      console.log("something wrong"))
  }
}
