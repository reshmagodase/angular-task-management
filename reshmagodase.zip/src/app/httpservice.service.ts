import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpserviceService {

  constructor(private http:HttpClient) { }
  
  postuserdata(data:any) : Observable<any>{
    console.log(data)
    return this.http.post("http://localhost:3000/posts",data)
  }

  getuserdata() : Observable<any>{
    // console.log(data)
    return this.http.get("http://localhost:3000/posts")
  }

  deletedata(id:any) : Observable<any>{
    // console.log(data)
    return this.http.delete("http://localhost:3000/posts/"+id)
  }

  updatadata(data:any, id:any) : Observable<any>{
    // console.log(data)
    return this.http.put("http://localhost:3000/posts/" +id,data)
  }

  adddata(data:any) : Observable<any>{
    // console.log(data)
    return this.http.post("http://localhost:3000/posts/",data)
  }
}
