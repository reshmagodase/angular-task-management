import { Component, OnInit } from '@angular/core';
import { HttpserviceService } from '../httpservice.service';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
userlist:any=[];
id:any;
userform:any=[];
username:any;
email:any;
 constructor( private serviceobj:HttpserviceService ,private fb:FormBuilder) { }

  ngOnInit(): void {
   this.getuser();

   this.userform= this.fb.group({
    username:[],
    email:[],
  })
  }
  getuser(){
    this.serviceobj.getuserdata().subscribe((res:any) =>{
      this.userlist=res;

  })
  }
  delete(id:any){
    this.serviceobj.deletedata(id).subscribe((res:any) =>{
      alert("record deleted");
      this.getuser();
    })
  }

  setdata(user:any){
    this.id=user.id;
    this.userform.controls['username'].setValue(user.username);
    this.userform.controls['email'].setValue(user.email)

  }
  updatedata(){
    this.serviceobj.updatadata(this.userform.value,this.id).subscribe((res:any) =>{
      alert("record updated successfully");
      this.getuser();
    })
  }


  adddata(){
    this.serviceobj.adddata(this.userform.value).subscribe((res:any) =>{
      alert("add data successfully");
      this.getuser();
    })
  }

  viewdata(user:any){
    this.id=user.id;
    this.username=user.username;
    this.email=user.email
  }
}
